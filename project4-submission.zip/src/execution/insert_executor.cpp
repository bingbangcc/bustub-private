//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// insert_executor.cpp
//
// Identification: src/execution/insert_executor.cpp
//
// Copyright (c) 2015-19, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//
#include <memory>

#include "execution/executors/insert_executor.h"

// insert的时候schema
namespace bustub {

InsertExecutor::InsertExecutor(ExecutorContext *exec_ctx, const InsertPlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan), child_executor_(std::move(child_executor)) {
  table_meta_data_ = exec_ctx->GetCatalog()->GetTable(plan_->TableOid());
  index_info_vec_ = exec_ctx->GetCatalog()->GetTableIndexes(table_meta_data_->name_);
}

void InsertExecutor::Init() {
  if (child_executor_ != nullptr) {
    child_executor_->Init();
  }
  cur_insert_pos_ = 0;
}

// 插入的数据和在表中存储的数据的scheme是相同的

bool InsertExecutor::Next([[maybe_unused]] Tuple *tuple, RID *rid) {
  // Transaction *txn = exec_ctx_->GetTransaction();
  // LockManager *lock_mgr = exec_ctx_->GetLockManager();

  if (plan_->IsRawInsert()) {
    const std::vector<std::vector<Value>> &raw_values = plan_->RawValues();
    if (cur_insert_pos_ >= raw_values.size()) {
      return false;
    }
    const auto &values = raw_values[cur_insert_pos_++];

    Tuple insert_tuple(values, &table_meta_data_->schema_);

    // // 获得x-lock
    // if (lock_mgr != nullptr) {
    //   if (txn->GetExclusiveLockSet()->count(*rid) == 0) {
    //     lock_mgr->LockExclusive(txn, *rid);
    //   }
    // }

    if (!table_meta_data_->table_->InsertTuple(insert_tuple, rid, exec_ctx_->GetTransaction())) {
      return false;
    }

    // 在txn中插入这条对table的修改记录
    // if (lock_mgr != nullptr) {
    //   txn->AppendTableWriteRecord({*rid, WType::INSERT, insert_tuple, table_meta_data_->table_.get()});
    // }

    for (auto &index_info : index_info_vec_) {
      auto cur_index = index_info->index_.get();
      Tuple key(
          insert_tuple.KeyFromTuple(table_meta_data_->schema_, index_info->key_schema_, cur_index->GetKeyAttrs()));
      cur_index->InsertEntry(key, *rid, exec_ctx_->GetTransaction());
      // 在txn中插入这条对index的修改记录
      // if (lock_mgr != nullptr) {
      //   txn->AppendIndexWriteRecord({*rid, plan_->TableOid(), WType::INSERT, insert_tuple, Tuple{},
      //                                index_info->index_oid_, exec_ctx_->GetCatalog()});
      // }
    }

    // }
    std::cout << "raw insert success" << std::endl;
    return true;
  }

  Tuple insert_tuple;
  // 从child处获得insert数据
  if (child_executor_->Next(&insert_tuple, rid)) {
    if (!table_meta_data_->table_->InsertTuple(insert_tuple, rid, exec_ctx_->GetTransaction())) {
      return false;
    }

    // if (lock_mgr != nullptr) {
    //   if (txn->GetExclusiveLockSet()->count(*rid) == 0) {
    //     lock_mgr->LockExclusive(txn, *rid);
    //   }
    // }

    // // 在txn中插入这条对table的修改记录
    // if (lock_mgr != nullptr) {
    //   txn->AppendTableWriteRecord({*rid, WType::INSERT, insert_tuple, table_meta_data_->table_.get()});
    // }

    for (auto &index_info : index_info_vec_) {
      auto cur_index = index_info->index_.get();
      Tuple key(
          insert_tuple.KeyFromTuple(table_meta_data_->schema_, index_info->key_schema_, cur_index->GetKeyAttrs()));
      cur_index->InsertEntry(key, *rid, exec_ctx_->GetTransaction());
      // 在txn中插入这条对index的修改记录
      // if (lock_mgr != nullptr) {
      //   txn->AppendIndexWriteRecord({*rid, plan_->TableOid(), WType::INSERT, insert_tuple, Tuple{},
      //                                index_info->index_oid_, exec_ctx_->GetCatalog()});
      // }
    }
    return true;
  }

  return false;
}

}  // namespace bustub
